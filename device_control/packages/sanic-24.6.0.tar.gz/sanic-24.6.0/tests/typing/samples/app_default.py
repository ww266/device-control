from sanic import Sanic


app = Sanic("test")
reveal_type(app)  # noqa
